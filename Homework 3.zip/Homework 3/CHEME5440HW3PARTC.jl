include("Flux.jl")

using LinearAlgebra

#Define the stoichiometrix matrix

Stoichiometric_matrix = Array{Float64,2}(undef,18,20)
Stoichiometric_matrix[1,:]=[-1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0];          #aspartate
Stoichiometric_matrix[2,:]=[1 -1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];          #argininosuccinate
Stoichiometric_matrix[3,:]=[0 1 0 0 0 0 0 0 -1 0 0 0 0 0 0 0 0 0 0 0];          #fumarate
Stoichiometric_matrix[4,:]=[0 1 -1 0 1 -1 0 0 0 0 0 0 0 0 0 0 0 0 0 0];         #arginine
Stoichiometric_matrix[5,:]=[0 0 1 0 0 0 0 0 0 -1 0 0 0 0 0 0 0 0 0 0];          #urea
Stoichiometric_matrix[6,:]=[0 0 1 -1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];          #ornithine
Stoichiometric_matrix[7,:]=[0 0 0 -1 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0];          #carbomoyl phosphate
Stoichiometric_matrix[8,:]=[-1 0 0 1 -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0];         #citruline
Stoichiometric_matrix[9,:]=[-1 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0];          #ATP
Stoichiometric_matrix[10,:]=[0 0 -1 0 -2 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0];        #H2O
Stoichiometric_matrix[11,:]=[0 0 0 1 0 0 0 0 0 0 0 0 -1 0 0 0 0 0 0 0];         #Pi
Stoichiometric_matrix[12,:]=[1 0 0 0 0 0 0 0 0 0 0 0 0 -1 0 0 0 0 0 0];         #AMP
Stoichiometric_matrix[13,:]=[1 0 0 0 0 0 0 0 0 0 0 0 0 0 -1 0 0 0 0 0];         #PPi
Stoichiometric_matrix[14,:]=[0 0 0 0 -1 1 0 0 0 0 0 0 0 0 0 -1 0 0 0 0];        #NO
Stoichiometric_matrix[15,:]=[0 0 0 0 2 -2 0 0 0 0 0 0 0 0 0 0 -1 0 0 0];        #O2
Stoichiometric_matrix[16,:]=[0 0 0 0 1.5 -1.5 0 0 0 0 0 0 0 0 0 0 0 1 0 0];     #H+
Stoichiometric_matrix[17,:]=[0 0 0 0 1.5 -1.5 0 0 0 0 0 0 0 0 0 0 0 0 1 0];     #NADPH
Stoichiometric_matrix[18,:]=[0 0 0 0 -1.5 1.5 0 0 0 0 0 0 0 0 0 0 0 0 0 -1];    #NADP+

#Given Kcat values
k_cat=Array{Float64,2}(undef,6,1)
k_cat[1]=203;   #EC: 6.3.4.5 (v1) [s^-1]
k_cat[2]=34.5;  #EC: 4.3.2.1 (v2) [s^-1]
k_cat[3]=249;   #EC: 3.5.3.1 (v3) [s^-1]
k_cat[4]=88.1;  #EC: 2.1.3.3 (v4) [s^-1]
k_cat[5]=13.7;  #EC: 1.14.13.39 (v5f) [s^-1]
k_cat[6]=13.7;  #EC: 1.14.13.39 (v5r) [s^-1]

E=0.01;         #micromole/gDW (steady-state concentration for enzymes in pathway)
theta=1;        #All enzymes are maximally active

#Define metabolite concentrations from Park et al. and BRENDA

metabolite_uM=Array{Float64,2}(undef,18,1)
metabolite_uM[1]=0.01492232040*1000000;        #aspartate
metabolite_uM[2]=0.0;                          #argininosuccinate
metabolite_uM[3]=0.00048507525189*1000000;     #fumarate
metabolite_uM[4]=0.000255461883*1000000;       #arginine
metabolite_uM[5]=0.0;                          #urea
metabolite_uM[6]=0.0044894266080*1000000;      #ornithine
metabolite_uM[7]=0.0;                          #carbamoyl phosphate
metabolite_uM[8]=0.0;                          #citruline
metabolite_uM[9]= 0.00006539521920*1000000     #ATP
metabolite_uM[10]=0.0;                         #H2O
metabolite_uM[11]=0.0;                         #Pi
metabolite_uM[12]=0.000042301635*1000000;      #AMP
metabolite_uM[13]=0.0;                         #PPi
metabolite_uM[14]=0.0                          #NO
metabolite_uM[15]=0.0;                         #O2
metabolite_uM[16]=0.0;                         #H+
metabolite_uM[17]=0.0000653952192*1000000;     #NADPH
metabolite_uM[18]=0.0005020260049*1000000;     #NADP+

#Convert concentration of metabolites from micromolar to micromol/gDW.

cell_volume=1e-12;                                #[L]
cell_mass=2.3e-9;                                 #[g]
water_fraction=0.798;                             #[%]
cell_drymass=(1-water_fraction)*cell_mass;
conversion(uM)=uM*(cell_volume)/cell_drymass;
metabolite=conversion(metabolite_uM)

#kM values from BRENDA and Park

kM_uM=Array{Float64,2}(undef,11,1)
kM_uM[1]=0.000154276895439494*1000000;          #aspartate6345(Park) v1 Mus Musculus
kM_uM[2]=0.0001*1000000;                        #arginosuccinate4321(Brenda) v2 Homo Sapiens
kM_uM[3]=0.00154608643830104*1000000;           #arginine3531(Park) v3 Homo Sapiens
kM_uM[4]=3.49694159840394;                      #arginine1141339(Park) v5r Mus Musculus
kM_uM[5]=0.00013*1000000;                       #carbomoylphosphate2133(Brenda) v4 Homo Sapiens
kM_uM[6]=0.0016*1000000;                        #ornithine2133(Park) v4 Sacchromyces Cerevisiae
kM_uM[7]=0.000056*1000000;                      #citruline6345(Brenda) v1 Homo Sapiens
kM_uM[8]=0.0;                                   #citruline1141339 v5f
kM_uM[9]=0.000392333154234199*1000000;          #ATP6345(Park) Mus Musculus
kM_uM[10]=0.0003*1000;                          #NADPH1141339(Brenda) v5r Mus Musculus
kM_uM[11]=0.0                                   #NADP+
kM=conversion(kM_uM)

#Flux bounds array.
#The default lower bounds are 0
#Upper bounds of the v fluxes
#theta = 1 (All enzymes are maximally active)

Default_bounds_array = zeros(20,2);

Default_bounds_array[1,2]=k_cat[1]*E*theta*(metabolite[1]/(metabolite[1]+kM[1]))*(metabolite[9]/(metabolite[9]+kM[9]))*1;
Default_bounds_array[2,2]=k_cat[2]*E*theta*1;
Default_bounds_array[3,2]=k_cat[3]*E*theta*(metabolite[4]/(metabolite[4]+kM[3]));
Default_bounds_array[4,2]=k_cat[4]*E*theta*(metabolite[6]/(metabolite[6]+kM[6]))*1;
Default_bounds_array[5,2]=k_cat[5]*E*theta*1;
Default_bounds_array[6,2]=k_cat[6]*E*theta*(metabolite[4]/(metabolite[4]+kM[4]))*(metabolite[17]/(metabolite[17]+kM[10]));

#Converting the upper bounds for the b fluxes to umol/gDW-s

Default_bounds_array[7,2]=(10*1000/3600);
Default_bounds_array[8,2]=(10*1000/3600);
Default_bounds_array[9,2]=(10*1000/3600);
Default_bounds_array[10,2]=(10*1000/3600);
Default_bounds_array[11,2]=(10*1000/3600);
Default_bounds_array[12,2]=(10*1000/3600);
Default_bounds_array[13,2]=(10*1000/3600);
Default_bounds_array[14,2]=(10*1000/3600);
Default_bounds_array[15,2]=(10*1000/3600);
Default_bounds_array[16,2]=(10*1000/3600);
Default_bounds_array[17,2]=(10*1000/3600);
Default_bounds_array[18,2]=(10*1000/3600);
Default_bounds_array[19,2]=(10*1000/3600);
Default_bounds_array[20,2]=(10*1000/3600);

#Different lower bounds for reversible reactions

Default_bounds_array[11,1]=-(10*1000/3600);
Default_bounds_array[12,1]=-(10*1000/3600);
Default_bounds_array[13,1]=-(10*1000/3600);
Default_bounds_array[14,1]=-(10*1000/3600);
Default_bounds_array[15,1]=-(10*1000/3600);
Default_bounds_array[16,1]=-(10*1000/3600);
Default_bounds_array[17,1]=-(10*1000/3600);
Default_bounds_array[18,1]=-(10*1000/3600);
Default_bounds_array[19,1]=-(10*1000/3600);
Default_bounds_array[20,1]=-(10*1000/3600);

#Define species bounds array and an objective function coefficient array to calculate optimal flux distribution

Species_bounds_array=zeros(18,2);
Objective_coefficient_array=zeros(20);
Objective_coefficient_array[10]=-1;

Min_flag = true;

#Use Flux.jl to calculate the optimal flux distribution
#Extract the flux vector and convert to mmol/gDW-hr

answer=calculate_optimal_flux_distribution(Stoichiometric_matrix,Default_bounds_array,Species_bounds_array,Objective_coefficient_array);

r=3600*answer[2]/1000; #[mmol/gDW-hr]

#Choose and print the urea flux b4

max_urea_flux=r[10]; #[mmol/gDW-hr]
println("Maximum Urea Flux in mmol/gDW-hr=",max_urea_flux)
